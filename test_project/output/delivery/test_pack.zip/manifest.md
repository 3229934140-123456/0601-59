# 交付清单

**项目名称**: test-project
**生成时间**: 2026-06-08 18:15:03
**主题**: default
**版权**: 无

## 文件统计

- 总文件数: 3
- 总大小: 1.4 KB
- 图片文件: 3
- 字体文件: 0
- 图标文件: 0
- 其他文件: 0

## 目录结构

```
├── default
│   └── test_red.png
├── test_blue.png
└── test_red.png
```

## 文件清单

| # | 文件名 | 类型 | 大小 |
|---|--------|------|------|
| 1 | default\test_red.png | png | 287 B |
| 2 | test_blue.png | png | 588 B |
| 3 | test_red.png | png | 587 B |
